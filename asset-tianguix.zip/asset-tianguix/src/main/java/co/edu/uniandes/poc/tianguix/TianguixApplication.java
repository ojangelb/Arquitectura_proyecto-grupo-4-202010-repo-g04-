package co.edu.uniandes.poc.tianguix;

import org.springframework.boot.autoconfigure.SpringBootApplication;

import static org.springframework.boot.SpringApplication.*;

@SpringBootApplication
public class TianguixApplication {

	public static void main(String[] args) {
		run(TianguixApplication.class, args);
	}

}
