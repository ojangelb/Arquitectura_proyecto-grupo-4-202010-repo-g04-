package co.edu.uniandes.poc.tianguix;

import org.junit.jupiter.api.Test;

class TianguixApplicationTests {

	@Test
	void contextLoads() {
	}

}
